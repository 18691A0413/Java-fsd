package com.example.DemonstrateRESTful;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemonstrateResTfulApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemonstrateResTfulApplication.class, args);
	}

}

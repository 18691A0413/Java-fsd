package com.example.DemonstrateRESTful.Repository;

public interface TaskRepository extends JpaRepository<Task, Long> {
}


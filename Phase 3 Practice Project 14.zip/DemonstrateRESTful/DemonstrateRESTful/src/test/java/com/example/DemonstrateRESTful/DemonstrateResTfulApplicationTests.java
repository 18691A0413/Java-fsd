package com.example.DemonstrateRESTful;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemonstrateResTfulApplicationTests {

	@Test
	void contextLoads() {
	}

}

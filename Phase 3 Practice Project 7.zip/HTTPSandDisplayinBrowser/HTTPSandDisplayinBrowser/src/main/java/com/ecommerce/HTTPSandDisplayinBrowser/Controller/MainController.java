package com.ecommerce.HTTPSandDisplayinBrowser.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {
    @GetMapping("/")
    public String hello() {
        return "index"; // Returns the name of the HTML template (without the .html extension)
    }
}

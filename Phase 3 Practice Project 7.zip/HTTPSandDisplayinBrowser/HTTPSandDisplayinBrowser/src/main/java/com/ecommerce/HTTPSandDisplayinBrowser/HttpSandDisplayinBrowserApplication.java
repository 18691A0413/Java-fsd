package com.ecommerce.HTTPSandDisplayinBrowser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpSandDisplayinBrowserApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpSandDisplayinBrowserApplication.class, args);
		System.out.print("App Started..");
	}

}

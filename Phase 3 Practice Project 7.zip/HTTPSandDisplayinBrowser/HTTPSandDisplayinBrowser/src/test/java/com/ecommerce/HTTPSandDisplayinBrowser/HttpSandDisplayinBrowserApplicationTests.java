package com.ecommerce.HTTPSandDisplayinBrowser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpSandDisplayinBrowserApplicationTests {

	@Test
	void contextLoads() {
	}

}

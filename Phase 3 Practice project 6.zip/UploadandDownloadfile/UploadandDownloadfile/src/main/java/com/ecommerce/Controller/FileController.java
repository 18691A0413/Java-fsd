package com.ecommerce.Controller;

import java.net.http.HttpHeaders;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecommerce.Service.FileStorageService;

import antlr.collections.List;

@Controller
public class FileController<FileEntity> {
    @Autowired
    private FileStorageService fileStorageService; // You need to implement this service

    @GetMapping("/")
    public String listUploadedFiles(Model model) {
        Object fileRepository;
		// Retrieve a list of uploaded files from the database if you're using one
        // Otherwise, retrieve the list from the file system
        List files = ((Object) fileRepository).findAll();
        model.addAttribute("files", files);
        return "upload-form";
    }

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
        // Save the file to the file system and, if needed, to the database
        // You can use a service for this
        fileStorageService.storeFile(file);
        return "redirect:/";
    }

    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId) {
        // Retrieve the file from the file system or the database
        // Create a Resource object and return it as ResponseEntity
        org.springframework.core.io.Resource resource = fileStorageService.loadFileAsResource(fileId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }
}


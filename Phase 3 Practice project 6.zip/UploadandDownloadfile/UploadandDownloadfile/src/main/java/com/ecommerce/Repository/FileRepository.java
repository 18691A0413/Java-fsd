package com.ecommerce.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.Entity.FileEntity;

public interface FileRepository extends JpaRepository<FileEntity, Long> {
    // Custom query methods, if needed
}

package com.ecommerce.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    @Value("${file.upload-dir}") // Define the directory where files will be stored in application.properties or application.yml
    private String uploadDir;

    public void storeFile(MultipartFile file) {
        String fileName = generateUniqueFileName(file.getOriginalFilename());

        try {
            Path targetLocation = Paths.get(uploadDir).resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            // Handle the exception as needed
        }
    }

    public Resource loadFileAsResource(Long fileId) {
        try {
            // Retrieve the file entity from the database or other storage mechanism
            // Get the filename associated with the file entity
            // Construct the file path
            String fileName = "example.jpg"; // Replace with actual filename
            Path filePath = Paths.get(uploadDir).resolve(fileName).normalize();
            Resource resource = new UrlResource(filePath.toUri());

            if (resource.exists()) {
                return resource;
            } else {
                // Handle the case when the file does not exist
            }
        } catch (MalformedURLException e) {
            // Handle the exception as needed
        }

        return null;
    }

    private String generateUniqueFileName(String originalFileName) {
        String fileExtension = StringUtils.getFilenameExtension(originalFileName);
        String randomFileName = UUID.randomUUID().toString();
        return randomFileName + "." + fileExtension;
    }
}

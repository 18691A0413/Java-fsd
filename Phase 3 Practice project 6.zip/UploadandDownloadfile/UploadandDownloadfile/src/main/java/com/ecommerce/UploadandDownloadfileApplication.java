package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadandDownloadfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadandDownloadfileApplication.class, args);
		System.out.println("App staarted..");
	}

}

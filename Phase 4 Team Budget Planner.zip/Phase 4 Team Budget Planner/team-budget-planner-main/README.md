# team-budget-planner
A program using JavaScript to decide the budget of a specific team

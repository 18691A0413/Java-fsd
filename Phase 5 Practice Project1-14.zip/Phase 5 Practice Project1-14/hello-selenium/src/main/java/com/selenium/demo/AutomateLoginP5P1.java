package com.selenium.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AutomateLoginP5P1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Phase5 Selenium\\chrome driver\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.shine.com/login/");
		
		//login button
				//WebElement login=driver.findElement(By.cssSelector("#loginContainer"));
				//login.click();
				
				 //login email
				 WebElement Email=driver.findElement(By.id("id_email_login"));
				 Email.sendKeys("Joshbosh123@foxisports.cf");
				 
				//password
				WebElement Password=driver.findElement(By.id("id_password"));
				Password.sendKeys("Nive@123");
				
				//button
				WebElement Login=driver.findElement(By.xpath("//*[@id=\"cndidate_login_widget\"]/form/ul[2]/li[4]/div/button"));
				Login.click();
	}
}